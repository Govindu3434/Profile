[![MasterHead](https://repository-images.githubusercontent.com/588181932/e36ec678-7984-4cdd-8e4c-a3932772ff8e)]
<h1 align="center"><samp>Vision Version Viral</samp> <img src="https://github.com/mupezzuol/mupezzuol/blob/master/assets/earth.gif" width="22px" height="22px"> </h1>

<h2 align="center"><samp>Hi 👋 I'm P.Govindu</samp></h2>
<h3 align="center"><samp>Iam Software developer | Web Developer from Hyderabad</samp> </h3>

<img align="center" alt="Coding" width="1000" src="https://raw.githubusercontent.com/sugith10/images/main/gif/mario-working.gif">

<p align="left"> <img src="https://komarev.com/ghpvc/?username=sufiyansgh&label=Profile%20views&color=0e75b6&style=flat" alt="sufiyan" /> </p>

<div style="margin-bottom: 200px;"></div>

- 🔭 I’m currently working on **EDULOG SMART FACULTY DOCUMENTATION HUB PROJECT**

- 🌱 I’m currently learning **Bootstrap, React,**

- 💬 Ask me about **Python HTML,CSS, JavaScript, React, Bootstrap.**

- 📫 How to reach me **vnani8219@gmail.com**

- ⚡ Fun fact **I am funny**

<samp>- 📫 Reach me at https://www.linkedin.com/public-profile/settings</samp>

<samp>- 📫 Reach me at vnani8219@gmail.com</samp>

<samp>- 📫 Reach me at https://www.instagram.com/vijay_nani_1432_?igsh=aGk5ejYwOHhjcGl0 </samp>

<samp>- 💻 Frontend Developer</samp>






<h3 align="center"><samp>Connect with me</samp></h3>
<div style="display: flex; align-items: flex-start; align: center">
<table align="center">
  <tr>
   <td align="center" width="100">
        <a href="https://www.linkedin.com/public-profile/settings"><img src="https://skillicons.dev/icons?i=linkedin" alt="icon" width="45" height="45" /></a>
      <br>Linkedin
    </td>
      <td align="center" width="100">
      <a heref="https://www.threads.com/@vijay_nani_1432_">
        <img src="https://skillicons.dev/icons?i=twitter" width="45" height="45" alt="SQ Lite" />
      <br>Twitter
    </td>
    <td align="center" width="100">
        <img src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/leet-code.svg" alt="icon" width="45" height="45" />
      <br>Leetcode
    </td>
       <td align="center" width="100">
        <img src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/medium.svg" alt="icon" width="45" height="45" />
      <br>Medium
      <td align="center" width="100">
       <image src="https://www.instagram.com/vijay_nani_1432_?igsh=aGk5ejYwOHhjcGl0 utm_source=ig_contact_invite" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="definitely._.not" height="45" width="45" /></a>
       <br>Instagram
    </td>
  </tr>
</table>
<br><br>
</div>


<h3 align="center"><samp>💻 Languages and Tools</samp></h3>
<div style="display: flex; align-items: flex-start; align: center">
<table align="center">
  <tr>
    <td align="center" width="100">
      <a href="#macropower-tech">
        <img src="https://skillicons.dev/icons?i=react" alt="icon" width="45" height="45" />
      </a>
      <br>React
    </td>
    <td align="center" width="100">
        <img src="https://skillicons.dev/icons?i=spring" alt="icon" width="45" height="45" />
      <br>Spring
    </td>
    <td align="center" width="100">
        <img src="https://skillicons.dev/icons?i=express" alt="icon" width="45" height="45" />
      </a>
      <br>ExpressJS
    </td>
      <td align="center" width="100">
        <img src="https://skillicons.dev/icons?i=ts" alt="icon" width="45" height="50" />
      <br>Typescript
    </td>
   <td align="center" width="100">
        <img src="https://skillicons.dev/icons?i=java" alt="icon" width="45" height="50" />
      <br>Java
    </td>
      <td align="center" width="100">
        <img src="https://skillicons.dev/icons?i=postgres" width="48" height="48" alt="SQ Lite" />
      <br>Postgres
    </td>
    <td align="center" width="100">
        <img src="https://skillicons.dev/icons?i=jquery" alt="icon" width="45" height="45" />
      <br>Jquery
    </td>
       <td align="center" width="100">
        <img src="https://skillicons.dev/icons?i=figma" alt="icon" width="45" height="45" />
      <br>Figma
    </td>
  </tr>
  <tr>
    <td align="center" width="100">
        <img src="https://techstack-generator.vercel.app/js-icon.svg" alt="icon" width="65" height="65" />
      <br>JavaScript
    </td>
    <td align="center"  width="100">
        <img src="https://skillicons.dev/icons?i=html" width="48" height="48" alt="HTML5" />
      <br>HTML5
    </td>
    <td align="center" width="100">
        <img src="https://skillicons.dev/icons?i=css" width="48" height="48" alt="css" />
      <br>CSS
    </td>
    <td align="center"  width="100">
        <img src="https://skillicons.dev/icons?i=bootstrap" width="48" height="48" alt="bootstrap" />
      <br>Bootstrap
    </td>
           <td align="center" width="100">
        <img src="https://skillicons.dev/icons?i=nodejs" width="48" height="48" alt="Nodejs" />
      <br>Nodejs
      </td>
          <td align="center" width="100">
        <img src="https://skillicons.dev/icons?i=mongodb" width="48" height="48" alt="MongoDB" />
      <br>MongoDB
    </td>
    <td align="center"  width="100">
        <img src="https://skillicons.dev/icons?i=mysql" width="48" height="48" alt="mysql" />
      <br>My SQL
    </td>
           <td align="center" width="100">
        <img src="https://techstack-generator.vercel.app/aws-icon.svg" alt="icon" width="65" height="65" />
      <br>AWS
    </td>
       
  </tr>
 <tr>
        <td align="center" width="100">
        <img src="https://skillicons.dev/icons?i=postman" width="48" height="48" alt="postman" />
      <br>Postman
    </td>
       <td align="center" width="100"> 
        <img src="https://user-images.githubusercontent.com/25181517/192108372-f71d70ac-7ae6-4c0d-8395-51d8870c2ef0.png" width="48" height="48" alt="Git" />
      <br>Git
    </td>
       <td align="center" width="100">
        <img src="https://skillicons.dev/icons?i=github" alt="icon" width="45" height="45" />
      <br>Github
    </td>
    <td align="center" width="100">
        <img src="https://skillicons.dev/icons?i=tailwind" width="48" height="48" alt="android studio" />
      <br>Tailwind
    </td>
            <td align="center" width="100">
        <img src="https://skillicons.dev/icons?i=ubuntu" width="48" height="48" alt="VsCode" />
      <br>Ubuntu
    </td>
      <td align="center" width="100">
        <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/linux/linux-original.svg" width="48" height="48" alt="linu" />
      <br>Linux
    </td>
     <td align="center" width="100">
        <img src="https://skillicons.dev/icons?i=vite" width="48" height="48" alt="firebase" />
      <br>Vite
    </td>
     <td align="center" width="100">
        <img src="https://skillicons.dev/icons?i=prisma" width="48" height="48" alt="linu" />
      <br>Prisma
    </td>          
 </tr>
</table>
<br><br>
</div>


<div style="margin-bottom: 60px;"></div>
<h3 align="center"><samp>✍️Random Dev Quote</samp></h3>
    <div align="center">
      <img src="https://quotes-github-readme.vercel.app/api?type=horizontal&theme=vue" alt="Random Dev Quote" />
    </div>

<div align="center">
  <h3>⚡️GitHub Stats:</h3>
<!--   <img src="https://github-readme-stats.vercel.app/api?username=sufiyansgh&theme=dark&hide_border=false&include_all_commits=true&count_private=false" alt="GitHub Stats" /><br/> -->
  <img src="https://nirzak-streak-stats.vercel.app/?user=sufiyansgh&theme=dark&hide_border=false" alt="GitHub Streak" /><br/>
  <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=sufiyansgh&theme=dark&hide_border=false&include_all_commits=true&count_private=false&layout=compact" alt="Top Languages" />
</div>

<div align="center">
  <picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/sufiyansgh/sufiyansgh/output/github-snake-dark.svg" />
  <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/sufiyansgh/sufiyansgh/output/github-snake.svg" />
  <img src="https://raw.githubusercontent.com/sufiyansgh/sufiyansgh/output/snake.svg" alt="Snake animation" />
</picture>
</div>





